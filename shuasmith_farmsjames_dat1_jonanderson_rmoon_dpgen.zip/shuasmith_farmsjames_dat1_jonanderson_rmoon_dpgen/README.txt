# Assignment-2
ECE574 Programming Assignment
Joshua Smith	shuasmith		ECE574
James Cole		farmsjames	ECE574
David Tondre	dat1				ECE574
Jon Anderson	jonanderson	ECE574
Randall Moon	rmoon				ECE574

This program takes in a behaviorial netlist and outputs a 
Vivado file which will implement the circuit described by the 
netlist and includes an estimate of the duration of the
critical path.

To execute compiled build, use "YourDirectory/dpgen XXXX.txt YYYY.v"
where XXXX represents the filename of the behavioral netlist and
YYYY represents the filename of the output Vivado code.

Joshua Smith - Troubleshoot code, ensure compliance to
	assignment requirements, tested code with ece3 server
James Cole - Programmed several modules of the code (particularly
	with calculating the critical path), helped troubleshoot issues
David Tondre - Created primary structure for the main body of the code, 
	ensured Vivado implementation was correct.
Jon Anderson - Programmed several subroutines, implemented Cmake, ensured
	compile would work with Linux
Randall Moon - Programmed subroutines to create the schedule, get estimated latency, 
	and calculate the critical path. Developed structure variables. 